# model_info_box.py – Box zur Anzeige von Modellinfos

# TODO: Tooltip oder Infofeld mit Preis, Tokens, Kontextlänge etc.
